# Lab 2
# cs100_lab2

This application uses several different routes to display the list of galleries ("index"), lists of objects in a gallery, and individual objects. It also uses a post method to add comments to a JavaScript object that stores lists of comments as values associated with object ID keys. When an individual object is displayed, the application iterates through the associated comments and lists only the comments for the given object ID. The application makes requests to the Museum's API when displaying the galleries list, an object list, and an individual object.
